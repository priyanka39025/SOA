package bean;

public class Trucks {
    private String TruckID;
	private String Make;
	private int Year;
	private String Model;
	private String LicensePlateNo;
	private String Color;
	private String VIN;
	private String DriverID;

    public String getTruckID() {
        return TruckID;
    }

    public void setTruckID(String TruckID) {
        this.TruckID = TruckID;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String Make) {
        this.Make = Make;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int Year) {
        this.Year = Year;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getLicensePlateNo() {
        return LicensePlateNo;
    }

    public void setLicensePlateNo(String LicensePlateNo) {
        this.LicensePlateNo = LicensePlateNo;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getVIN() {
        return VIN;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public String getDriverID() {
        return DriverID;
    }

    public void setDriverID(String DriverID) {
        this.DriverID = DriverID;
    }	
	
}