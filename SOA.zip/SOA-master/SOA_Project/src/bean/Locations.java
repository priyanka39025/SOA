package bean;

public class Locations {
    private String LocationID;
	private String LocName;
	private String LocationCode;
	private String IsAuction;
    private String CustomerID;
	private String Address_Street1;
	private String Address_street2;
	private String City;
	private String State;
    private int PostalCode;
	private String Region;
	private String Location_contact_name;
	private int LocPhone;
	private int LocFaxNumber;
	private String LocEmail;

    public String getLocationID() {
        return LocationID;
    }

    public void setLocationID(String LocationID) {
        this.LocationID = LocationID;
    }

    public String getLocName() {
        return LocName;
    }

    public void setLocName(String LocName) {
        this.LocName = LocName;
    }

    public String getLocationCode() {
        return LocationCode;
    }

    public void setLocationCode(String LocationCode) {
        this.LocationCode = LocationCode;
    }

    public String getIsAuction() {
        return IsAuction;
    }

    public void setIsAuction(String IsAuction) {
        this.IsAuction = IsAuction;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }
    
    public String getAddress_Street1() {
        return Address_Street1;
    }

    public void setAddress_Street1(String Address_Street1) {
        this.Address_Street1 = Address_Street1;
    }

    public String getAddress_street2() {
        return Address_street2;
    }

    public void setAddress_street2(String Address_street2) {
        this.Address_street2 = Address_street2;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public int getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(int PostalCode) {
        this.PostalCode = PostalCode;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getLocation_contact_name() {
        return Location_contact_name;
    }

    public void setLocation_contact_name(String Location_contact_name) {
        this.Location_contact_name = Location_contact_name;
    }

    public int getLocPhone() {
        return LocPhone;
    }

    public void setLocPhone(int LocPhone) {
        this.LocPhone = LocPhone;
    }

    public int getLocFaxNumber() {
        return LocFaxNumber;
    }

    public void setLocFaxNumber(int LocFaxNumber) {
        this.LocFaxNumber = LocFaxNumber;
    }

    public String getLocEmail() {
        return LocEmail;
    }

    public void setLocEmail(String LocEmail) {
        this.LocEmail = LocEmail;
    }
        
}